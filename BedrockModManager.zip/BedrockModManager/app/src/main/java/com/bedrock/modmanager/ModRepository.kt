package com.bedrock.modmanager

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.provider.OpenableColumns
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.FilterInputStream
import java.io.InputStream
import java.security.MessageDigest
import java.util.UUID
import java.util.zip.ZipInputStream

enum class ImportResult { ADDED, DUPLICATE, UNSUPPORTED, FAILED }

class ModRepository(private val context: Context) {

    companion object {
        val SUPPORTED = setOf("mcpack", "mcaddon", "mcworld", "mctemplate")
        private const val MAX_ICON_BYTES = 2 * 1024 * 1024
    }

    private val root = File(context.filesDir, "mods").apply { mkdirs() }
    private val iconsDir = File(context.filesDir, "icons").apply { mkdirs() }
    private val indexFile = File(context.filesDir, "index.json")

    fun file(item: ModItem) = File(File(root, item.id), item.fileName)
    fun iconFile(id: String) = File(iconsDir, "$id.png")

    @Synchronized
    fun list(): List<ModItem> {
        if (!indexFile.exists()) return emptyList()
        return try {
            val arr = JSONArray(indexFile.readText())
            (0 until arr.length()).map {
                val o = arr.getJSONObject(it)
                ModItem(
                    o.getString("id"), o.getString("displayName"), o.getString("fileName"),
                    o.getString("ext"), o.getLong("size"), o.getLong("addedAt"),
                    o.getString("hash"), o.optBoolean("hasIcon", false)
                )
            }.filter { file(it).exists() }
        } catch (e: Exception) {
            emptyList()
        }
    }

    @Synchronized
    private fun write(items: List<ModItem>) {
        val arr = JSONArray()
        items.forEach {
            arr.put(JSONObject().apply {
                put("id", it.id); put("displayName", it.displayName); put("fileName", it.fileName)
                put("ext", it.ext); put("size", it.size); put("addedAt", it.addedAt)
                put("hash", it.hash); put("hasIcon", it.hasIcon)
            })
        }
        val tmp = File(context.filesDir, "index.json.tmp")
        tmp.writeText(arr.toString())
        if (!tmp.renameTo(indexFile)) {
            indexFile.writeText(arr.toString()); tmp.delete()
        }
    }

    @Synchronized
    fun delete(item: ModItem) {
        File(root, item.id).deleteRecursively()
        iconFile(item.id).delete()
        write(list().filter { it.id != item.id })
    }

    @Synchronized
    fun import(uri: Uri): ImportResult {
        var name: String? = null
        try {
            context.contentResolver.query(uri, null, null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (i >= 0) name = c.getString(i)
                }
            }
        } catch (_: Exception) { }
        val original = (name ?: uri.lastPathSegment ?: "mod").substringAfterLast('/')
        val ext = original.substringAfterLast('.', "").lowercase()
        if (ext !in SUPPORTED) return ImportResult.UNSUPPORTED

        val safeName = original.replace(Regex("[\\\\/:*?\"<>|]"), "_")
        val id = UUID.randomUUID().toString()
        val dir = File(root, id).apply { mkdirs() }
        val out = File(dir, safeName)
        try {
            val md = MessageDigest.getInstance("SHA-256")
            val input = context.contentResolver.openInputStream(uri)
            if (input == null) {
                dir.deleteRecursively()
                return ImportResult.FAILED
            }
            input.use { ins ->
                out.outputStream().use { os ->
                    val buf = ByteArray(64 * 1024)
                    while (true) {
                        val n = ins.read(buf)
                        if (n < 0) break
                        md.update(buf, 0, n)
                        os.write(buf, 0, n)
                    }
                }
            }
            val hash = md.digest().joinToString("") { "%02x".format(it) }
            val current = list()
            if (current.any { it.hash == hash }) {
                dir.deleteRecursively()
                return ImportResult.DUPLICATE
            }
            val hasIcon = extractIcon(out, id)
            val item = ModItem(
                id, safeName.substringBeforeLast('.'), safeName, ext,
                out.length(), System.currentTimeMillis(), hash, hasIcon
            )
            write(current + item)
            return ImportResult.ADDED
        } catch (e: Exception) {
            dir.deleteRecursively()
            return ImportResult.FAILED
        }
    }

    // ---------- استخراج أيقونة الحزمة (pack_icon.png) ----------

    private fun extractIcon(file: File, id: String): Boolean {
        return try {
            file.inputStream().buffered().use { raw ->
                val bytes = ZipInputStream(raw).use { findIcon(it, 0) }
                bytes != null && saveIcon(bytes, id)
            }
        } catch (e: Exception) {
            false
        }
    }

    private fun findIcon(zis: ZipInputStream, depth: Int): ByteArray? {
        var entry = zis.nextEntry
        while (entry != null) {
            val n = entry.name.lowercase()
            if (!entry.isDirectory) {
                if (n.endsWith("pack_icon.png") || n.endsWith("pack_icon.jpg") || n.endsWith("world_icon.jpeg")) {
                    readLimited(zis)?.let { return it }
                } else if (depth < 1 && (n.endsWith(".mcpack") || n.endsWith(".zip"))) {
                    val shield = object : FilterInputStream(zis) { override fun close() {} }
                    try {
                        findIcon(ZipInputStream(shield), depth + 1)?.let { return it }
                    } catch (_: Exception) { }
                }
            }
            entry = zis.nextEntry
        }
        return null
    }

    private fun readLimited(ins: InputStream): ByteArray? {
        val bos = ByteArrayOutputStream()
        val buf = ByteArray(16 * 1024)
        while (true) {
            val n = ins.read(buf)
            if (n < 0) break
            bos.write(buf, 0, n)
            if (bos.size() > MAX_ICON_BYTES) return null
        }
        return bos.toByteArray()
    }

    private fun saveIcon(bytes: ByteArray, id: String): Boolean {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return false
        var sample = 1
        while (bounds.outWidth / (sample * 2) >= 192) sample *= 2
        val bmp = BitmapFactory.decodeByteArray(
            bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = sample }
        ) ?: return false
        val scaled = Bitmap.createScaledBitmap(bmp, 160, 160, true)
        FileOutputStream(iconFile(id)).use { scaled.compress(Bitmap.CompressFormat.PNG, 100, it) }
        return true
    }
}
