package com.bedrock.modmanager

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class ModItem(
    val id: String,
    val displayName: String,
    val fileName: String,
    val ext: String,
    val size: Long,
    val addedAt: Long,
    val hash: String,
    val hasIcon: Boolean
)

object Fmt {
    fun size(bytes: Long): String {
        val kb = 1024.0
        val mb = kb * 1024
        val gb = mb * 1024
        return when {
            bytes >= gb -> String.format(Locale.US, "%.2f GB", bytes / gb)
            bytes >= mb -> String.format(Locale.US, "%.1f MB", bytes / mb)
            bytes >= kb -> String.format(Locale.US, "%.0f KB", bytes / kb)
            else -> "$bytes B"
        }
    }

    fun date(ms: Long): String =
        SimpleDateFormat("yyyy/MM/dd  HH:mm", Locale.US).format(Date(ms))
}
