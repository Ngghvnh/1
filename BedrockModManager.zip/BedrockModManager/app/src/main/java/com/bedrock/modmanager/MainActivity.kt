package com.bedrock.modmanager

import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.PopupMenu
import androidx.core.content.FileProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.button.MaterialButton
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {

    private enum class Sort { DATE, NAME, SIZE }

    private val minecraftPackages = listOf("com.mojang.minecraftpe", "com.mojang.minecraftpe.preview")

    private lateinit var repo: ModRepository
    private lateinit var adapter: ModAdapter
    private lateinit var tvEmpty: TextView
    private lateinit var progress: View
    private lateinit var btnSort: MaterialButton
    private lateinit var etSearch: EditText
    private lateinit var statMods: TextView
    private lateinit var statSize: TextView
    private lateinit var statFiles: TextView

    private val io = Executors.newSingleThreadExecutor()
    private var all: List<ModItem> = emptyList()
    private var sort = Sort.DATE

    private val picker = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) importAll(uris)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        repo = ModRepository(this)

        tvEmpty = findViewById(R.id.tvEmpty)
        progress = findViewById(R.id.progress)
        btnSort = findViewById(R.id.btnSort)
        etSearch = findViewById(R.id.etSearch)
        statMods = findViewById(R.id.statMods)
        statSize = findViewById(R.id.statSize)
        statFiles = findViewById(R.id.statFiles)

        adapter = ModAdapter(repo, ::installInMinecraft, ::confirmDelete)
        findViewById<RecyclerView>(R.id.recycler).apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            adapter = this@MainActivity.adapter
        }

        findViewById<View>(R.id.btnAdd).setOnClickListener { picker.launch(arrayOf("*/*")) }
        btnSort.setOnClickListener { showSortMenu() }
        etSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) = applyFilter()
        })

        refresh()
    }

    override fun onDestroy() {
        super.onDestroy()
        io.shutdown()
    }

    // ---------- القائمة ----------

    private fun refresh() {
        all = repo.list()
        statMods.text = all.count { it.ext == "mcpack" || it.ext == "mcaddon" }.toString()
        statFiles.text = all.size.toString()
        statSize.text = Fmt.size(all.sumOf { it.size })
        applyFilter()
    }

    private fun applyFilter() {
        val q = etSearch.text.toString().trim().lowercase()
        var list = if (q.isEmpty()) all else all.filter {
            it.displayName.lowercase().contains(q) || it.fileName.lowercase().contains(q)
        }
        list = when (sort) {
            Sort.DATE -> list.sortedByDescending { it.addedAt }
            Sort.NAME -> list.sortedBy { it.displayName.lowercase() }
            Sort.SIZE -> list.sortedByDescending { it.size }
        }
        adapter.submitList(list)
        if (list.isEmpty()) {
            tvEmpty.setText(if (all.isEmpty()) R.string.empty else R.string.no_results)
            tvEmpty.visibility = View.VISIBLE
        } else {
            tvEmpty.visibility = View.GONE
        }
    }

    private fun showSortMenu() {
        val pm = PopupMenu(this, btnSort)
        pm.menu.add(0, 0, 0, R.string.sort_date)
        pm.menu.add(0, 1, 1, R.string.sort_name)
        pm.menu.add(0, 2, 2, R.string.sort_size)
        pm.setOnMenuItemClickListener {
            sort = Sort.values()[it.itemId]
            btnSort.text = it.title
            applyFilter()
            true
        }
        pm.show()
    }

    // ---------- الاستيراد ----------

    private fun importAll(uris: List<Uri>) {
        progress.visibility = View.VISIBLE
        io.execute {
            val counts = IntArray(ImportResult.values().size)
            uris.forEach { counts[repo.import(it).ordinal]++ }
            runOnUiThread {
                progress.visibility = View.GONE
                refresh()
                val parts = mutableListOf<String>()
                val added = counts[ImportResult.ADDED.ordinal]
                val dup = counts[ImportResult.DUPLICATE.ordinal]
                val uns = counts[ImportResult.UNSUPPORTED.ordinal]
                val fail = counts[ImportResult.FAILED.ordinal]
                if (added > 0) parts += getString(R.string.import_done, added)
                if (dup > 0) parts += getString(R.string.import_dup, dup)
                if (uns > 0) parts += getString(R.string.import_unsupported, uns)
                if (fail > 0) parts += getString(R.string.import_failed, fail)
                Toast.makeText(this, parts.joinToString(" \u2022 "), Toast.LENGTH_LONG).show()
            }
        }
    }

    // ---------- الحذف ----------

    private fun confirmDelete(item: ModItem) {
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.confirm_delete_title)
            .setMessage(getString(R.string.confirm_delete_msg, item.displayName))
            .setNegativeButton(R.string.cancel, null)
            .setPositiveButton(R.string.delete) { _, _ ->
                io.execute {
                    repo.delete(item)
                    runOnUiThread {
                        refresh()
                        Toast.makeText(this, R.string.deleted, Toast.LENGTH_SHORT).show()
                    }
                }
            }
            .show()
    }

    // ---------- التثبيت في Minecraft (Intent + FileProvider) ----------

    @Suppress("DEPRECATION")
    private fun isInstalled(pkg: String): Boolean = try {
        packageManager.getPackageInfo(pkg, 0)
        true
    } catch (e: Exception) {
        false
    }

    private fun installInMinecraft(item: ModItem) {
        val file = repo.file(item)
        if (!file.exists()) {
            Toast.makeText(this, R.string.file_missing, Toast.LENGTH_SHORT).show()
            refresh()
            return
        }
        val target = minecraftPackages.firstOrNull { isInstalled(it) }
        if (target == null) {
            MaterialAlertDialogBuilder(this)
                .setTitle(R.string.mc_not_installed_title)
                .setMessage(R.string.mc_not_installed_msg)
                .setPositiveButton(R.string.ok, null)
                .show()
            return
        }
        val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, "application/octet-stream")
            setPackage(target)
            clipData = ClipData.newRawUri(item.fileName, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        try {
            startActivity(intent)
        } catch (e: ActivityNotFoundException) {
            try {
                intent.setPackage(null)
                startActivity(Intent.createChooser(intent, getString(R.string.install)))
            } catch (e2: Exception) {
                Toast.makeText(this, R.string.open_failed, Toast.LENGTH_LONG).show()
            }
        } catch (e: SecurityException) {
            Toast.makeText(this, R.string.open_failed, Toast.LENGTH_LONG).show()
        }
    }
}
