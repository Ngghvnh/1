package com.bedrock.modmanager

import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.LruCache
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.button.MaterialButton

class ModAdapter(
    private val repo: ModRepository,
    private val onInstall: (ModItem) -> Unit,
    private val onDelete: (ModItem) -> Unit
) : ListAdapter<ModItem, ModAdapter.VH>(Diff) {

    private val cache = LruCache<String, Bitmap>(64)

    object Diff : DiffUtil.ItemCallback<ModItem>() {
        override fun areItemsTheSame(a: ModItem, b: ModItem) = a.id == b.id
        override fun areContentsTheSame(a: ModItem, b: ModItem) = a == b
    }

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val icon: ImageView = v.findViewById(R.id.ivIcon)
        val name: TextView = v.findViewById(R.id.tvName)
        val meta: TextView = v.findViewById(R.id.tvMeta)
        val date: TextView = v.findViewById(R.id.tvDate)
        val install: MaterialButton = v.findViewById(R.id.btnInstall)
        val delete: ImageButton = v.findViewById(R.id.btnDelete)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_mod, parent, false))

    override fun onBindViewHolder(h: VH, position: Int) {
        val item = getItem(position)
        val ctx = h.itemView.context
        h.name.text = item.displayName
        h.meta.text = "${item.ext.uppercase()} \u2022 ${Fmt.size(item.size)}"
        h.date.text = ctx.getString(R.string.added_on, Fmt.date(item.addedAt))

        val bmp = if (item.hasIcon) loadIcon(item.id) else null
        h.icon.clipToOutline = true
        if (bmp != null) {
            h.icon.setPadding(0, 0, 0, 0)
            h.icon.imageTintList = null
            h.icon.scaleType = ImageView.ScaleType.CENTER_CROP
            h.icon.setImageBitmap(bmp)
        } else {
            val p = (14 * ctx.resources.displayMetrics.density).toInt()
            h.icon.setPadding(p, p, p, p)
            h.icon.scaleType = ImageView.ScaleType.FIT_CENTER
            h.icon.imageTintList = ColorStateList.valueOf(ContextCompat.getColor(ctx, R.color.green))
            h.icon.setImageResource(R.drawable.ic_package)
        }

        h.install.setOnClickListener { onInstall(item) }
        h.delete.setOnClickListener { onDelete(item) }

        h.itemView.alpha = 0f
        h.itemView.translationY = 24f
        h.itemView.animate().alpha(1f).translationY(0f).setDuration(260).start()
    }

    private fun loadIcon(id: String): Bitmap? {
        cache.get(id)?.let { return it }
        val f = repo.iconFile(id)
        if (!f.exists()) return null
        val b = BitmapFactory.decodeFile(f.absolutePath) ?: return null
        cache.put(id, b)
        return b
    }
}
